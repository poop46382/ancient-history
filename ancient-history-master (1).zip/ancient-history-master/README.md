The Ladybird web browser has moved into the SerenityOS monorepo.

You'll find it under [/Ladybird](https://github.com/SerenityOS/serenity/tree/master/Ladybird)
